package com.APICRUD.operation.Dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.APICRUD.operation.Entity.Student;

@Repository
public class StudentDao {

	@Autowired
	SessionFactory SF;
	public List<Student> getallData() {
		
		Session session = SF.openSession();
		Criteria criteria = session.createCriteria(Student.class);
		List<Student> list =criteria.list();
		return list;
	}
	
	public String insertData(List<Student> s) {
		
		Session session = SF.openSession();
		Transaction tr =session.beginTransaction();
		for (Student data : s) {
			session.save(data);
		}
		tr.commit();
		return "Insert Data Successfully";
	}
	public String updateData(Student Stud) {

        Session session = SF.openSession();
        Transaction tr =session.beginTransaction();
        session.saveOrUpdate(Stud);
        tr.commit();
        return"Data Update Seccessful";
		
	}

	public Student deleteData(int Id) {
		
		Session session = SF.openSession();
		Transaction tr = session.beginTransaction();
		Student s = session.get(Student.class, Id);
		session.delete(s);
		tr.commit();
		return s;
		
	}

}
