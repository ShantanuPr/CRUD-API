package com.APICRUD.operation.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.APICRUD.operation.Dao.StudentDao;
import com.APICRUD.operation.Entity.Student;

@Service
public class StudentService {

	@Autowired
	StudentDao SD;
	
	public List<Student> getallData() {
		
		List<Student> list =SD.getallData();
		return list;
		
	}

	public String insertData(List<Student>s) {
		
		String msg =SD.insertData(s);
		return msg;
	}

	public String updateData(Student Stud) {
		
		String msg = SD.updateData(Stud);
		return msg;
	}

	public Student deleteData(int Id) {
		
		Student data =SD.deleteData(Id);
		return data;
		
	}

}
