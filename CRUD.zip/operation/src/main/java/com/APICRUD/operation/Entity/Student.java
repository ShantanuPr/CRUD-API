package com.APICRUD.operation.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Student {

	int Id;
	String Name;
	int Marks;
	String Date;
	
	@Id
	public int getId() {
		return Id;
	}
	
	public void  setId(int Id) {
		this.Id=Id;
	}
	
	public String getName() {
		return Name;
	}
	
	public void  setName(String Name) {
		this.Name=Name;
	}
	
	public int getMarks() {
		return Marks;
	}
	
	public void  setMarks(int Marks) {
		this.Marks=Marks;
	}
	
	public String getDate() {
		return Date;
	}
	
	public void setDate(String Date) {
		this.Date=Date;
	}

	@Override
	public String toString() {
		return "Student [Id=" + Id + ", Name=" + Name + ", Marks=" + Marks + ", Date=" + Date + "]";
	}
	
	
}
